class Solution(object):
    def twoSum(self, nums, target):
        """
        :type nums: List[int]
        :type target: int
        :rtype: List[int]
        """
        dictio = {}
        other = 0
        for i, num in enumerate(nums) :
            other = target - num
            if other in dictio :
                return [dictio[other], i]
            else :
                dictio[num] = i