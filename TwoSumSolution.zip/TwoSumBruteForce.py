class Solution(object):
    def twoSum(self, nums, target):
        """
        :type nums: List[int]
        :type target: int
        :rtype: List[int]
        """
        arr = []
        for i in range(len(nums)) :
            for j in range(i) :
                if nums[i] + nums[j] == target :
                    arr.append(i)
                    arr.append(j)
        return arr